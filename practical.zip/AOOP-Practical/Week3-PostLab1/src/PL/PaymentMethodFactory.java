package PL;

public interface PaymentMethodFactory {
	PaymentMethod createPaymentMethod();
}
