package PL;

public interface VehicleFactory {
	Vehicle createVehicle();
}
