package PL;

public interface PaymentMethod {
	void pay(double amount);
}
