package game;

public interface PowerUp {
	void activate();
}
