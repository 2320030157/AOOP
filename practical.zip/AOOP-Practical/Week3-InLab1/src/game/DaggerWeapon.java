package game;

public class DaggerWeapon implements Weapon {
	public void use() {
        System.out.println("Dagger weapon used!");
    }
}
