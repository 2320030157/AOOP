package game;

public class ShieldPowerUp implements PowerUp {
	 public void activate() {
        System.out.println("Shield power-up activated!");
    }
}
