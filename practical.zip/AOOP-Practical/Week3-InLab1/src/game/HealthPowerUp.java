package game;

public class HealthPowerUp implements PowerUp {
	public void activate() {
        System.out.println("Health power-up activated");
    }
}
