package workersystem;

public interface Eater {
    void eat();
}
