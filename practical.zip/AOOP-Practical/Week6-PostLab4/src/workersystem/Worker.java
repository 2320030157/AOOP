package workersystem;

public interface Worker {
    void work();
}
