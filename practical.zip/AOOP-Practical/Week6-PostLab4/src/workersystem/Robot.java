package workersystem;

public class Robot implements Worker {
    @Override
    public void work() {
        System.out.println("The robot is working.");
    }
}
